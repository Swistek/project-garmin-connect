describe ('Visit Home Page', () => {
    it('Should open home page', () => {
        cy.visit('https://jobandtalent.com/')
    })
})