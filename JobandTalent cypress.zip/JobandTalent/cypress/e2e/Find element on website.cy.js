describe ('Visit Home Page', () => {
    it('Should open home page', () => {
        cy.visit('https://jobandtalent.com/')
    })

    it('Should wait for 3 seconds', () => {
        cy.wait(3000)
    })

    it('Should check for correct element on the page: Find work and stability with Jobandtalent', () => {
        cy.get('h1').should('be.visible')
    })
})