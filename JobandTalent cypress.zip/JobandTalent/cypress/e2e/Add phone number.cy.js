describe ('Visit Home Page', () => {
    it('Should open home page', () => {
        cy.visit('https://jobandtalent.com/')
    })

it('Should add phone number in field', () => {
    cy.get('#sms_sender_phone_number').click({force:true}).type('1234567890')

})


})