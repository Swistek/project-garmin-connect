describe ('Visit Home Page', () => {
    it('Should open home page', () => {
        cy.visit('https://jobandtalent.com/')
    })

    it('Should wait for 3 seconds', () => {
        cy.wait(3000)
    })

    it('Should check url address', () => {
        cy.url().should('include', 'talent.com')
    })

    it('Should find Get started button', () => {
        cy.get('.landing_top_section_cta_candidates').contains('Get started')
    })
})