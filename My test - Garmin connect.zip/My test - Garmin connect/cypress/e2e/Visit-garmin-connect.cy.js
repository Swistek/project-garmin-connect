describe('Login to page', () => {
it('Should load correct url page', () => {
    cy.visit('/')
})

it('Should check correct url', () => {
    cy.url().should('include', 'garmin.com')
})

it('In the upper left corner of the page is "connect" text', () => {
    cy.get('h1').should('be.visible')
})

})
