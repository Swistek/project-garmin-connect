describe('Signin to application - unhappy path', () => {
  it('Should visit Signin page', () => {
    cy.visit('https://connect.garmin.com/')
    cy.url().should('include', 'garmin.com/')
    cy.get('a >.c0149').should('be.visible')
    cy.get('a >.c0149').click()
    cy.url().should('include', 'signin')
})

it('Should Signin with invaild credentials', () => {
  cy.get('input#username').type('invalid@email.com')
  cy.get('input#password').type('invalidpassword')
  cy.get('button#login-btn-signin').click()
  cy.get('.form-alert > #status').should('be.visible')
})


})

